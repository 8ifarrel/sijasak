<?php $__env->startSection('slot'); ?>
<div class="h-screen-fix flex items-center justify-center bg-gradient-to-br p-5">
  <form method="POST" action="<?php echo e(route('auth.login.submit')); ?>" class="w-full max-w-sm space-y-8">
    <?php echo csrf_field(); ?>
    <div class="text-center mb-6">
      <img src="<?php echo e(asset('logos/sijasak.png')); ?>" class="h-12 w-auto mx-auto mb-2" alt="<?php echo e(config('app.name_short')); ?>">
      <h1 class="text-2xl font-bold text-gray-800 mb-1 tracking-tight">Login Admin</h1>
      <p class="text-gray-500 text-sm">Masuk untuk mengelola website <span class="font-semibold text-biru"><?php echo e(config('app.name_short')); ?> <?php echo e(config('app.location')); ?></span></p>
    </div>
    <!-- Username Floating Input -->
    <div class="relative">
      <input
        type="text"
        id="hs-floating-underline-input-username"
        name="username"
        value="<?php echo e(old('username')); ?>"
        class="peer py-4 px-0 block w-full bg-transparent border-t-transparent border-b-2 border-x-transparent border-b-gray-200 sm:text-sm placeholder:text-transparent focus:border-t-transparent focus:border-x-transparent focus:border-b-blue-500 focus:ring-0 disabled:opacity-50 disabled:pointer-events-none
        focus:pt-6
        focus:pb-2
        not-placeholder-shown:pt-6
        not-placeholder-shown:pb-2
        autofill:pt-6
        autofill:pb-2 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 focus:border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        placeholder="Username"
        required
        autofocus
        autocomplete="username"
      >
      <label for="hs-floating-underline-input-username"
        class="absolute top-0 start-0 py-4 px-0 h-full sm:text-sm truncate pointer-events-none transition ease-in-out duration-100 border border-transparent  origin-[0_0] peer-disabled:opacity-50 peer-disabled:pointer-events-none
        peer-focus:scale-90
        peer-focus:translate-x-0.5
        peer-focus:-translate-y-1.5
        peer-focus:text-gray-500 
        peer-not-placeholder-shown:scale-90
        peer-not-placeholder-shown:translate-x-0.5
        peer-not-placeholder-shown:-translate-y-1.5
        peer-not-placeholder-shown:text-gray-500 ">
        Username
      </label>
      <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <!-- Password Floating Input -->
    <div class="relative">
      <input
        type="password"
        id="hs-floating-underline-input-password"
        name="password"
        class="peer py-4 px-0 block w-full bg-transparent border-t-transparent border-b-2 border-x-transparent border-b-gray-200 sm:text-sm placeholder:text-transparent focus:border-t-transparent focus:border-x-transparent focus:border-b-blue-500 focus:ring-0 disabled:opacity-50 disabled:pointer-events-none 
        focus:pt-6
        focus:pb-2
        not-placeholder-shown:pt-6
        not-placeholder-shown:pb-2
        autofill:pt-6
        autofill:pb-2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 focus:border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        placeholder="********"
        required
        autocomplete="current-password"
      >
      <label for="hs-floating-underline-input-password"
        class="absolute top-0 start-0 py-4 px-0 h-full sm:text-sm truncate pointer-events-none transition ease-in-out duration-100 border border-transparent  origin-[0_0] peer-disabled:opacity-50 peer-disabled:pointer-events-none
        peer-focus:scale-90
        peer-focus:translate-x-0.5
        peer-focus:-translate-y-1.5
        peer-focus:text-gray-500 
        peer-not-placeholder-shown:scale-90
        peer-not-placeholder-shown:translate-x-0.5
        peer-not-placeholder-shown:-translate-y-1.5
        peer-not-placeholder-shown:text-gray-500">
        Password
      </label>
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <!-- Remember Me & Submit -->
    <div class="flex items-center justify-between">
      <div class="flex items-center">
        <input id="remember-me" name="remember-me" type="checkbox"
          class="h-4 w-4 text-biru border-gray-300 rounded accent-biru"
          <?php echo e(old('remember-me') ? 'checked' : ''); ?>>
        <label for="remember-me" class="ml-2 text-sm text-gray-600">Ingati saya</label>
      </div>
    </div>
    <button type="submit"
      class="w-full py-3 rounded-lg bg-biru hover:bg-kuning text-kuning hover:text-biru font-semibold text-base shadow-sm transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 flex items-center justify-center gap-2">
      <i class="fa-solid fa-arrow-right-to-bracket"></i>
      Masuk
    </button>
    <div class="text-center text-xs text-gray-400 mt-8">
      &copy; <?php echo e(date('Y')); ?> Kelompok 4
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/sijasak/resources/views/auth/pages/login/index.blade.php ENDPATH**/ ?>