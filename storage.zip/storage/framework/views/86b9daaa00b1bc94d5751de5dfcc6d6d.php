

<?php $__env->startSection('slot'); ?>
<div class="">
    <div class="">
        <div class="p-4 sm:p-6">
            <h1 class="font-semibold text-2xl md:text-3xl">
                <?php echo e($page_title); ?>

            </h1>

            <main class="mt-4">
                <form action="<?php echo e(route('admin.jalan-rusak.update', $jalan_rusak->id)); ?>" method="POST"
                    enctype="multipart/form-data" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    
                    <div>
                        <label for="deskripsi" class="block text-sm font-semibold text-gray-700 mb-1">Deskripsi</label>
                        <textarea id="deskripsi" name="deskripsi" rows="3" required
                            class="w-full rounded-lg border border-gray-300 bg-white focus:border-primary-500 focus:ring-primary-500 transition px-3 py-2"><?php echo e(old('deskripsi', $jalan_rusak->deskripsi)); ?></textarea>
                        <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="foto" class="block text-sm font-semibold text-gray-700 mb-1">Foto</label>
                        <label id="foto-label" for="foto"
                            class="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition relative overflow-hidden">
                            <div id="foto-placeholder"
                                class="flex flex-col items-center justify-center pt-5 pb-6 hidden">
                                <svg class="w-8 h-8 mb-2 text-gray-400" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-4 4h-4a1 1 0 01-1-1v-1h10v1a1 1 0 01-1 1h-4z" />
                                </svg>
                                <p class="mb-1 text-sm text-gray-500"><span class="font-semibold">Klik untuk
                                        upload</span> atau drag & drop</p>
                                <p class="text-xs text-gray-400">PNG, JPG, JPEG (max 2MB)</p>
                            </div>
                            <img id="foto-preview" src="<?php echo e(asset('storage/' . $jalan_rusak->foto)); ?>" alt="Preview"
                                class="absolute inset-0 w-full h-full object-contain rounded-lg bg-white" />
                        </label>
                        <input id="foto" name="foto" type="file" accept="image/*" class="hidden" />
                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex flex-col gap-y-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-3">
                            
                            <div>
                                <label for="longitude"
                                    class="block text-sm font-semibold text-gray-700 mb-1">Longitude</label>
                                <input type="number" step="any" id="longitude" name="longitude"
                                    value="<?php echo e(old('longitude', $jalan_rusak->longitude)); ?>" required
                                    class="w-full rounded-lg border border-gray-300 bg-white focus:border-primary-500 focus:ring-primary-500 transition px-3 py-2"
                                    placeholder="-6.1234567">
                                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div>
                                <label for="latitude"
                                    class="block text-sm font-semibold text-gray-700 mb-1">Latitude</label>
                                <input type="number" step="any" id="latitude" name="latitude"
                                    value="<?php echo e(old('latitude', $jalan_rusak->latitude)); ?>" required
                                    class="w-full rounded-lg border border-gray-300 bg-white focus:border-primary-500 focus:ring-primary-500 transition px-3 py-2"
                                    placeholder="106.1234567">
                                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <button type="button" id="detect-location-btn"
                                class="inline-flex items-center px-3 py-2 rounded-lg border border-primary-500 text-primary-600 bg-white hover:bg-primary-50 transition text-sm font-medium"
                                title="Deteksi lokasi sekarang">
                                <i class="fa-solid fa-location-crosshairs mr-1"></i>
                                Deteksi longitude & latitude
                            </button>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-3">
                        
                        <div>
                            <label for="tingkat_keparahan"
                                class="block text-sm font-semibold text-gray-700 mb-1">Tingkat Keparahan</label>
                            <select id="tingkat_keparahan" name="tingkat_keparahan" required
                                class="w-full rounded-lg border border-gray-300 bg-white focus:border-primary-500 focus:ring-primary-500 transition px-3 py-2">
                                <option value="ringan" <?php echo e(old('tingkat_keparahan', $jalan_rusak->tingkat_keparahan) ==
                                    'ringan' ? 'selected' : ''); ?>>Ringan</option>
                                <option value="sedang" <?php echo e(old('tingkat_keparahan', $jalan_rusak->tingkat_keparahan) ==
                                    'sedang' ? 'selected' : ''); ?>>Sedang</option>
                                <option value="berat" <?php echo e(old('tingkat_keparahan', $jalan_rusak->tingkat_keparahan) ==
                                    'berat' ? 'selected' : ''); ?>>Berat</option>
                            </select>
                            <?php $__errorArgs = ['tingkat_keparahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div>
                            <label for="sudah_diperbaiki" class="block text-sm font-semibold text-gray-700 mb-1">Status
                                Perbaikan</label>
                            <select id="sudah_diperbaiki" name="sudah_diperbaiki" required
                                class="w-full rounded-lg border border-gray-300 bg-white focus:border-primary-500 focus:ring-primary-500 transition px-3 py-2">
                                <option value="0" <?php echo e(old('sudah_diperbaiki', $jalan_rusak->sudah_diperbaiki) == 0 ?
                                    'selected' : ''); ?>>Belum diperbaiki</option>
                                <option value="1" <?php echo e(old('sudah_diperbaiki', $jalan_rusak->sudah_diperbaiki) == 1 ?
                                    'selected' : ''); ?>>Sudah diperbaiki</option>
                            </select>
                            <?php $__errorArgs = ['sudah_diperbaiki'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="flex gap-2">
                        <button type="submit"
                            class="bg-biru text-kuning preline-btn preline-btn-primary w-auto block py-2 px-3 font-semibold rounded-lg shadow hover:shadow-md transition">
                            <i class="fa-solid fa-save mr-1"></i> Ubah
                        </button>
                        <a href="<?php echo e(route('admin.jalan-rusak.index')); ?>"
                            class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition">
                            <i class="fa-solid fa-times mr-1"></i>Batal
                        </a>
                    </div>
                </form>
            </main>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const input = document.getElementById('foto');
        const preview = document.getElementById('foto-preview');
        const placeholder = document.getElementById('foto-placeholder');

        input.addEventListener('change', function(e) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(ev) {
                    preview.src = ev.target.result;
                    preview.classList.remove('hidden');
                    placeholder.classList.add('hidden');
                };
                reader.readAsDataURL(input.files[0]);
            }
        });

        // Location detection
        const detectBtn = document.getElementById('detect-location-btn');
        const longitudeInput = document.getElementById('longitude');
        const latitudeInput = document.getElementById('latitude');

        detectBtn.addEventListener('click', function() {
            detectBtn.disabled = true;
            detectBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Memproses...';

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        longitudeInput.value = position.coords.longitude;
                        latitudeInput.value = position.coords.latitude;
                        detectBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs mr-1"></i>Deteksi longitude & latitude';
                        detectBtn.disabled = false;
                    },
                    function(error) {
                        alert('Gagal mendapatkan lokasi: ' + error.message);
                        detectBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs mr-1"></i>Deteksi longitude & latitude';
                        detectBtn.disabled = false;
                    }
                );
            } else {
                alert('Browser tidak mendukung geolocation.');
                detectBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs mr-1"></i>Deteksi longitude & latitude';
                detectBtn.disabled = false;
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.jalan-rusak', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\farrel-punya\sijasak\resources\views/admin/pages/jalan-rusak/edit.blade.php ENDPATH**/ ?>