<div class="flex flex-col gap-2">
  <label class="inline-flex items-center gap-2">
    <input type="checkbox" class="form-checkbox accent-kuning" id="jalanRusakRingan" checked>
    <span><i class="fa-solid fa-circle-exclamation text-yellow-400"></i> Rusak Ringan</span>
  </label>
  <label class="inline-flex items-center gap-2">
    <input type="checkbox" class="form-checkbox accent-kuning" id="jalanRusakSedang" checked>
    <span><i class="fa-solid fa-triangle-exclamation text-orange-400"></i> Rusak Sedang</span>
  </label>
  <label class="inline-flex items-center gap-2">
    <input type="checkbox" class="form-checkbox accent-kuning" id="jalanRusakBerat" checked>
    <span><i class="fa-solid fa-triangle-exclamation text-red-600"></i> Rusak Berat</span>
  </label>
</div>
<?php /**PATH D:\farrel-punya\sijasak\resources\views/components/jalan-rusak-filter.blade.php ENDPATH**/ ?>