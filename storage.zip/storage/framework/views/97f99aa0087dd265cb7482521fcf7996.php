

<?php $__env->startSection('slot'); ?>

	<div 
		class="p-4 sm:ml-64">
		<div
			class="p-4 mt-14">
			<div>
				<h1
					class="font-semibold text-2xl md:text-3xl">
					<?php echo e($page_title); ?>

				</h1>

				<main
					class="mt-5">
					
					<div
						class="w-full p-4 rounded-lg shadow-xl sm:p-8">
						<h5 
							class="mb-2 text-3xl font-bold text-center md:text-start text-gray-900">
							Selamat Datang di Admin Panel
						</h5>

						<p
							class="mb-5 text-base text-center md:text-start text-gray-500 sm:text-lg">
							Kelola website <?php echo e(config('app.name')); ?> (<?php echo e(config('app.name_short')); ?>) <?php echo e(config('app.location')); ?> di sini
						</p>
					</div>
					
					
					<div
						class="w-full p-4 rounded-lg shadow-xl mt-5 sm:p-8">
						<h5 
							class="mb-2 text-3xl font-bold text-center md:text-start text-gray-900">
							Statistik Jalan Rusak
						</h5>

						<div class="p-4 bg-white rounded-lg md:p-8" id="stats" role="tabpanel" aria-labelledby="stats-tab">
							<dl class="grid max-w-screen-xl grid-cols-1 gap-8 mx-auto text-gray-900 sm:grid-cols-2">
								
								<div class="text-center block max-w-sm p-3 bg-white rounded-lg shadow-lg border-s-4 border-white border-l-red-600  hover:bg-gray-100">
									<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">3</h5>
									<p class="font-normal text-gray-700 dark:text-gray-400">Jumlah jalan rusak</p>
								</div>

                                
								<div class="text-center block max-w-sm p-3 bg-white rounded-lg shadow-lg border-s-4 border-white border-l-green-700  hover:bg-gray-100">
									<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">0</h5>
									<p class="font-normal text-gray-700 dark:text-gray-400">Jumlah jalan telah diperbaiki</p>
								</div>
							</dl>
						</div>

						
					</div>
				</main>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\farrel-punya\sijasak\resources\views/admin/pages/dashboard/index.blade.php ENDPATH**/ ?>